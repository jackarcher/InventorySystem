package boundary;

public class testMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UserInterface ui = new UserInterface();
		ui.start();
	}

}
